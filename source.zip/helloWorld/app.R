#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#


library(shiny)
library(ggplot2)
library(dplyr)
library(tidyverse)
library(shinydashboard)
library(lubridate)
library(DT)
library(jpeg)
library(grid)
library(leaflet)
library(scales)
library(shinyalert)

years<-c(2018:1980)
pollutants<-c("Days.CO", 'Days.NO2',
              'Days.SO2', 'Days.PM2.5',
              'Days.PM10', 'Days.Ozone')

ui <- dashboardPage(
  dashboardHeader(title = "CS 424 Spring 2019 Project 1"),
  dashboardSidebar(disable = FALSE, collapsed = FALSE,
                   selectInput("year", "Select the year to visualize", years, selected = 2018),
                   selectInput("pollutant", "Select pollutant to visualize", pollutants, selected = "Days.CO"),
                   uiOutput("stateOutput"), uiOutput("countyOutput"),uiOutput("countyState"),
                   useShinyalert(),  # Set up shinyalert
                   actionButton("info", "Info")
  ),
  dashboardBody(
              
              fluidRow(
                column(6,               
                       h4(textOutput("title1")),
                       tabsetPanel(
                       tabPanel("Pie Chart",plotOutput("pie")),
                       tabPanel("Bar Chart", plotOutput("bar")),
                       tabPanel("Table",tableOutput("results"))
                       )
                ),
                column(6, 
                  h4(textOutput("title2")),
                  tabsetPanel(
                  tabPanel("Pie Chart",plotOutput("pieq")),
                  tabPanel("Bar Chart", plotOutput("barq")),
                  tabPanel("Table",tableOutput("results2"))
                ))
                
                ),
              fluidRow(
                tabsetPanel(
                  tabPanel("AQI",plotOutput("hist1")),
                  tabPanel("Pollutants", plotOutput("hist2"))
                )
                  ),
              leafletOutput("mymap")
  ))



data <- read.csv("annual_aqi_by_county_1987.csv", stringsAsFactors = FALSE)
locations_file <- read.csv("sites/aqs_sites.csv", stringsAsFactors = FALSE)

temp = list.files(pattern="*.csv")
allData2 <- lapply(temp, function(x) read.csv(x, stringsAsFactors = FALSE))
allData3 <- do.call(rbind, allData2)

listNames <- c(colnames(data))


server <- function(input, output) {
  theme_set(theme_grey(base_size = 18)) 
  output$title1 <- renderText({
    paste(" AQI Days for ", input$countyInput, ", ",input$stateInput, ", ",input$year)
  })
  output$title2 <- renderText({
    paste(input$pollutant," Days for ", input$countyInput, ", ",input$stateInput, ", ",input$year)
  })
  output$countyOutput <- renderUI({
    req(input$stateInput)
    #print(allData3 %>% filter(State == input$stateInput)$County)
    selectInput("countyInput", "County",
                sort(unique((allData3 %>% filter(State == input$stateInput))$County)),
                selected = "Cook")
  })  
  output$stateOutput <- renderUI({
    selectInput("stateInput", "State",
                sort(unique(allData3$State)),
                selected = "Illinois")
  })  
  
  output$countyState <- renderUI({
    selectInput("stateCountyInput", "State & County",with(data, paste(County, State), selected = "Cook, Illinois"))
  })  
  
  db_location <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    
    db_location <- 
      req(input$stateInput)
      req(input$countyInput)
      locations_file[!(is.na(locations_file$Longitude) | is.na(locations_file$Latitude)),] %>%
      filter(State.Name == input$stateInput, County.Name == input$countyInput) %>%
      dplyr::select(c('Latitude', 'Longitude')) 
      
  })
  
  db_quality <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    req(input$year)
    year <- input$year

    db_quality <- allData3 %>%
      filter(Year == year, State == input$stateInput, County == input$countyInput) %>%
      dplyr::select(c('State', 'County', 'Year', "Good.Days", 'Moderate.Days',
                      'Unhealthy.for.Sensitive.Groups.Days', 'Unhealthy.Days',
                      'Very.Unhealthy.Days', 'Hazardous.Days')) %>%
      gather(key = 'Quality', value = 'Value', -State, -County, -Year)
  })
 
  db_pollutants <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    req(input$stateInput)
    req(input$year)
    
    year <- input$year
    pollutants <- input$pollutants
    db_pollutants<- allData3 %>%
      filter(Year == year, State == input$stateInput, County == input$countyInput) %>%
      dplyr::select(c('State', 'County', 'Year', "Days.CO", 'Days.NO2', 'Days.NO2', 'Days.PM10','Days.Ozone',
                      'Days.SO2', 'Days.PM2.5','Days.with.AQI'
                      )) %>%
      
     
      gather(key = 'Pollutants', value = 'Value', -State, -County, -Year)
  })
  
  
  db_percentage <- reactive({db_quality()})

  
  
  db_quality_tbl <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    req(input$stateInput)
    req(input$year)
    year <- input$year
    
    db_quality_tbl <- allData3 %>%
      filter(Year == year, State == input$stateInput, County == input$countyInput) %>%
      dplyr::select(c("Good.Days", 'Moderate.Days',
                      'Unhealthy.for.Sensitive.Groups.Days', 'Unhealthy.Days',
                      'Very.Unhealthy.Days', 'Hazardous.Days')) %>%
      gather(key = 'Quality', value = 'Value')
     
  })

  
  db_pol <- reactive({  
    selectedPollutantDays <- filter(db_pollutants(), Pollutants == input$pollutant)$Value  
    daysWithAQI <- filter(db_pollutants(), Pollutants == 'Days.with.AQI')$Value - selectedPollutantDays  
    label <- paste("Days with no ", input$pollutant)  
    db_pol <- data.frame(  
      Pollutants = c(label, input$pollutant),  
      Value = c(daysWithAQI, selectedPollutantDays)  
    )  
  })
 
  
  output$bar <- renderPlot(ggplot(db_quality(), aes(x=Quality, y=Value, fill=Quality))+
                             geom_bar(stat = "identity")+ scale_fill_manual(values=c("#999999", "#E69F00", "#56B4E9", "green", "blue", "black")))
  output$pie <- renderPlot(ggplot(db_quality(), aes(x="", y=Value, fill=Quality))+
                             geom_bar(width = 1, stat = "identity") + coord_polar("y", start=0))
  output$barq <- renderPlot(ggplot(db_pol(), aes(x="", y=Value, fill=Pollutants))+
                             geom_bar(width = 1, stat = "identity"))
  output$pieq <- renderPlot(ggplot(db_pol(), aes(x="", y=Value, fill=Pollutants))+
                             geom_bar(width = 1, stat = "identity") + coord_polar("y", start=0))
  tmp <- reactive({
    filter(allData3, Year == input$year)})
  results <- renderTable({
    db_quality_tbl()
  })
  output$results2 <- renderTable({
    db_pol()
  })
  output$results <- results

  observeEvent(input$info, {
    # Show a modal when the button is pressed
    shinyalert("Info", "Written By: Casey Charlesworth 
               Data From: https://aqs.epa.gov/aqsweb/airdata/download_files.html
               Libraries: shiny, ggplot2, dplyr, tidyverse, shinydashboard, lubridate, shinyalert, DT, jpeg, grid, leaflet, scales ", type = "info")
  })
  
  db_yrs <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    req(input$stateInput)

    db_yrs<- allData3 %>%
      filter(State == input$stateInput, County == input$countyInput) 
      
  })
  output$hist1 <- renderPlot({
    ggplot() +
    geom_line(data=db_yrs(), aes(x=Year, y=Max.AQI, group=1, color="red"))+
    geom_line(data=db_yrs(), aes(x=Year, y=Median.AQI, group=1, color="blue"))+
      geom_line(data=db_yrs(), aes(x=Year, y= X90th.Percentile.AQI, group=1, color="green"))+
    geom_point() +
      labs(title = "Max.AQI, Median.AQI, 90th Percentile AQI\n", x = "Years", y = "Values", color = "Legend Title\n")+
      scale_color_manual(name="Legend Title", 
                         labels = c("Median AQI", 
                                    "90th Percentile AQI", 
                                    "Max AQI"
                                    ), 
                         values = c("red"="red", 
                                    "blue"="blue", 
                                    "green"="green"))
      
  })
  
  db_pollutantsAll <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    req(input$stateInput)
    
    pollutants <- input$pollutants
    db_pollutantAlls<- allData3 %>%
      filter(State == input$stateInput, County == input$countyInput) %>%
      dplyr::select(c('State', 'County', 'Year', "Days.CO", 'Days.NO2', 'Days.PM10','Days.Ozone',
                      'Days.SO2', 'Days.PM2.5','Days.with.AQI'
      )) %>%
      mutate(Days.CO = (Days.CO/Days.with.AQI)*100, Days.NO2 = (Days.NO2/Days.with.AQI)*100,
             Days.SO2 = (Days.SO2/Days.with.AQI)*100,Days.PM2.5 = (Days.PM2.5/Days.with.AQI)*100,
             Days.PM10 = (Days.PM10/Days.with.AQI)*100, Days.Ozone = (Days.Ozone/Days.with.AQI)*100) 
    
  })
  
  output$hist2 <- renderPlot({
    ggplot() +
      geom_line(data=db_pollutantsAll(), aes(x=Year, y=Days.CO, group=1, color="red"))+
      geom_line(data=db_pollutantsAll(), aes(x=Year, y=Days.NO2, group=1, color="blue"))+
      geom_line(data=db_pollutantsAll(), aes(x=Year, y= Days.SO2, group=1, color="green"))+
      
      geom_line(data=db_pollutantsAll(), aes(x=Year, y= Days.PM2.5, group=1, color="black"))+
      geom_line(data=db_pollutantsAll(), aes(x=Year, y= Days.PM10, group=1, color="purple"))+
      geom_line(data=db_pollutantsAll(), aes(x=Year, y= Days.Ozone, group=1, color="orange"))+
      geom_point() +
      labs(title = "Pollutants Percentages\n", x = "Years", y = "Values", color = "Legend Title\n")+
      scale_color_manual(name="Legend Title", 
                         labels = c("Days.SO2", 
                                    "Days.PM10",
                                    "Days.PM2.5", 
                                    "Days.Ozone",
                                    "Days.NO2", 
                                    "Days.CO"
                         ), 
                         values = c("red"="red", 
                                    "blue"="blue", 
                                    "green"="green",
                                    "black"="black",
                                    "purple"="purple",
                                    "orange"="orange"
                                    ))
    
  })
  
  points <- eventReactive(input$recalc, {
    cbind(rnorm(40) * 2 + 13, rnorm(40) + 48)
  }, ignoreNULL = FALSE)
  
  lat <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    db_location()[1,1]
  })
  lon <- reactive({
    req(input$stateInput)
    req(input$countyInput)
    db_location()[1,2]
  })
  
  output$mymap <- renderLeaflet({
    req(lon())
    req(lat())

    df = data.frame(Lat = lat(), Long = lon())
    leaflet(df) %>% setView(lon(), lat(), 10) %>%
      addProviderTiles(providers$Stamen.TonerLite,
                       options = providerTileOptions(noWrap = TRUE)
      )  %>% addCircleMarkers(radius = runif(100, 4, 5), color = c('red'))
  })

  observe({
    #print(db_location())
  })
  
}


shinyApp(ui, server)

